<?php
require './includes/header.inc.php';
require './includes/nav.inc.php';
?>

    <div class="container">
        <div class="banner">
            <h1>Coming Soon!</h1>
        </div>
    </div><!--end container-->


    <!--FOOTER-->
<?php
include './includes/footer.inc.php';
?>