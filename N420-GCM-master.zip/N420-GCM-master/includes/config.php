<?php
ini_set('display_errors', E_ALL);

//added paths for files to reference to
define('ABSOLUTE_PATH', '/public_html');
define('URL_ROOT', 'http://www.joannaschweiger.com');



//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'joaschwe');
define('DB_PASS', 'joaschwe');
define('DB_NAME', 'joaschwe_db');
?>
